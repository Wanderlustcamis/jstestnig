function tips () {
  var t = [" drink water"," sleep well"," eat healthy"," skin care"," meditation"," yoga"]
    alert ("Here are some tips; " + t)
}
