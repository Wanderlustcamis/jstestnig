function week () {
    var d = prompt ("which day?");
    var days = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
    var dia = ""
    var i = 0;
        while (i< days.length)
        var dia = days[i]
          console.log(days);
          i++
          for (var num = 0; num < 7; num++)
            switch (num){
              case num = 0:
                alert("Yoga days")
                break
                case num = 2:
                  alert("Yoga days")
                  break
                  case num = 4:
                    alert("Yoga days")
                    break
                case num == 6:
                  alert("SUNDAY FUNDAY!")
                  break
                case num = 1:
                  alert("Exercise")
        	         break
                case num = 3:
             alert("Exercise")
             break
                case num = 5:
                alert("Exercise")
                break

         }
              num++
            }
