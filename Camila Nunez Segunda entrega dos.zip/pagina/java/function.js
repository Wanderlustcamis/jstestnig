function promedio (n1, n2)
    {
      var n1 = prompt ("add a number")
      var n2 = prompt ("add another number")
    alert (Number (n1) + Number (n2)/2)
  }
