var jsoninfo = {
  "age": "32",
  "weight": "60",
  "height": "1.57"

}

alert(jsoninfo).alert()


console.log(json["age"]);
