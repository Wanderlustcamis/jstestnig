var nh = new health ("; eat well", " excersise", " meditate")
var r = document.getElementById("resultado")

  function ver () {
    alert("Healthy lifestyle" + nh.food +","+ nh.life + " and" + nh.living)
  }

  function cal(){
    r.alert = c.cal
}
