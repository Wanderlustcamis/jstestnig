var json = {
  "age" "32"
  "weight" "60"
  "height" "1.57"

alert (json)};

consol.log(json ["age"]);
