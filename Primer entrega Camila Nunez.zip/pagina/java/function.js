var n1 = prompt ("add a number")
var n2 = prompt ("add another number")
 
  function promedio (num1, num2){
    return (Number (num1) + Number (num2))/2
  }
