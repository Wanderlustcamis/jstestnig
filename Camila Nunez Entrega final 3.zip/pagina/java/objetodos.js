var nh = new health ("; eat well", " excersise", " meditate")


  function ver () {
    alert("Healthy lifestyle" + nh.food +","+ nh.life + " and" + nh.living)
  }

 