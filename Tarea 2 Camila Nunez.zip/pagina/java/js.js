var numero = prompt ("add a number");
if (numero > 1000)
{  alert ("hey!") }
var texto = prompt ("say hi!");
if (texto = "hi")
  { console.log = ("they said hi!!")  }
var masnumeros = prompt ("add a number");
  masnumeros = Number(masnumeros);
  if (masnumeros > 10 && masnumeros < 50)
  {   alert ("yey!");}
