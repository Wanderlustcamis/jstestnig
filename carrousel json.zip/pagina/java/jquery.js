$(function (){
    $("#show").click(function(){
      $("#see").show(2000);
    });
    $("#hide").click(function(){
      $("#see").hide(2000);
    })
})
