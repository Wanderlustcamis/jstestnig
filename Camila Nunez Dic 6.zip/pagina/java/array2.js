function med(){
  var m = ['meditate 20 minutes twice a day'];
  var t =[' for a better spiritual growth.'];
  var y = " you can do it";
  var mix = m.concat(t);
  alert (mix + y)
}
