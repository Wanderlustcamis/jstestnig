function week () {
    var d = prompt ("which day?");
    var days = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
    var dia = days[i]
        while  (i< days.length){
          console.log(days);
          i++
        }
          for ( var i = 0; i < 7; i++)
            switch (i){
              case "0":
                alert ("Yoga day")
                break
                case "2":
                  alert ("Yoga days")
                  break
                  case "4":
                    alert("Yoga days")
                    break
                case "6":
                  alert("SUNDAY FUNDAY!")
                  break
                case "1":
                  alert("Exercise")
        	         break
                case "3":
             alert("Exercise")
             break
                case "5":
                alert("Exercise")
                break

         }

            }
