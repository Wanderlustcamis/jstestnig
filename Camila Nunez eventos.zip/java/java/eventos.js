imagen.AddEventListener ("mouseover",()=> imagen.style.cursor = "zoom-in")
